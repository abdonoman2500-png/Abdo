import type { Metadata, Viewport } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800", "900"],
  variable: "--font-cairo",
  display: "swap",
});

export const metadata: Metadata = {
  title: "عبود — لتحميل الفيديو من جميع المنصات",
  description:
    "عبود لتحميل الفيديوهات برابط مباشر من يوتيوب وتيك توك وإنستغرام وإكس وفيسبوك لأجهزة الآيفون والأندرويد وحفظها مباشرة في استوديو الصور.",
  manifest: "/manifest.webmanifest",
  applicationName: "عبود",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "عبود",
  },
  formatDetection: { telephone: false },
  icons: {
    icon: "/icon.svg",
    apple: "/icons/icon-512.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#02050c",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={cairo.variable}>
      <body className="min-h-full bg-[#02050c] text-white antialiased">{children}</body>
    </html>
  );
}
