"use client";

import { useEffect, useState } from "react";
import {
  IconAlert,
  IconCheck,
  IconCheckCircle,
  IconCopy,
  IconDown,
  IconShare,
  IconShield,
  IconSpinner,
  IconX,
} from "@/components/icons";
import { formatBytes } from "@/lib/platforms";

export interface DirectSaveModalProps {
  url: string;
  title: string;
  onClose: () => void;
}

interface ShareNav {
  canShare?: (data: { files: File[] }) => boolean;
  share?: (data: { files?: File[]; title?: string; text?: string; url?: string }) => Promise<void>;
}

export function DirectSaveModal({ url, title, onClose }: DirectSaveModalProps) {
  const [status, setStatus] = useState<"downloading" | "ready" | "shared" | "error">("downloading");
  const [progressPercent, setProgressPercent] = useState<number>(15);
  const [fileBlob, setFileBlob] = useState<Blob | null>(null);
  const [videoBlobUrl, setVideoBlobUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [isSharing, setIsSharing] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let isCancelled = false;
    const ctrl = new AbortController();

    // Progress animation while fetching
    const progressInterval = setInterval(() => {
      setProgressPercent((prev) => {
        if (prev >= 92) return prev;
        return prev + Math.floor(Math.random() * 8 + 4);
      });
    }, 280);

    (async () => {
      try {
        const query = new URLSearchParams({
          url: url,
          quality: "best",
          title: "video",
        });

        const res = await fetch(`/api/download?${query.toString()}`, { signal: ctrl.signal });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const blob = await res.blob();
        if (isCancelled) return;

        clearInterval(progressInterval);
        setProgressPercent(100);
        setFileBlob(blob);

        const vUrl = URL.createObjectURL(blob);
        setVideoBlobUrl(vUrl);
        setStatus("ready");

        // Automatically trigger native sharing if possible
        const nav = navigator as unknown as ShareNav;
        const safeFile = new File([blob], "video.mp4", { type: "video/mp4" });

        if (nav.canShare && nav.canShare({ files: [safeFile] }) && nav.share) {
          try {
            await nav.share({
              files: [safeFile],
              title: title || "فيديو",
            });
            if (!isCancelled) setStatus("shared");
          } catch {
            // If user dismissed or activation timed out, the ready state lets them tap once
          }
        } else {
          // Automatic direct download fallback
          try {
            const a = document.createElement("a");
            a.href = vUrl;
            a.download = "video.mp4";
            document.body.appendChild(a);
            a.click();
            a.remove();
          } catch {
            /* ignore */
          }
        }
      } catch (err: unknown) {
        if (!isCancelled) {
          clearInterval(progressInterval);
          setStatus("error");
          setErrorMessage("تعذّر تنزيل الفيديو من الرابط، يرجى التأكد من أن الرابط عام وصالح.");
        }
      }
    })();

    return () => {
      isCancelled = true;
      ctrl.abort();
      clearInterval(progressInterval);
      if (videoBlobUrl) URL.revokeObjectURL(videoBlobUrl);
    };
  }, [url, title]);

  /* ---------------- Direct 1-Tap Share to Photos Trigger ---------------- */
  async function triggerShareNow() {
    if (!fileBlob) return;
    setIsSharing(true);
    const nav = navigator as unknown as ShareNav;
    const safeFile = new File([fileBlob], "video.mp4", { type: "video/mp4" });

    if (nav.share) {
      try {
        await nav.share({
          files: [safeFile],
          title: title || "فيديو",
        });
        setStatus("shared");
        setIsSharing(false);
        return;
      } catch (e: unknown) {
        const err = e as { name?: string };
        if (err?.name === "AbortError") {
          setIsSharing(false);
          return;
        }
      }
    }

    // Direct download file fallback
    if (videoBlobUrl) {
      const a = document.createElement("a");
      a.href = videoBlobUrl;
      a.download = "video.mp4";
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
    setIsSharing(false);
  }

  function handleDirectDownload() {
    if (!videoBlobUrl) return;
    const a = document.createElement("a");
    a.href = videoBlobUrl;
    a.download = "video.mp4";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function handleCopy() {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(url).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      });
    }
  }

  return (
    <div className="fixed inset-0 z-[110] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md select-none">
      {/* Background overlay click to close */}
      <button aria-label="إغلاق" onClick={onClose} className="absolute inset-0 h-full w-full cursor-default" />

      {/* Futuristic Cyber Modal */}
      <div className="anim-rise relative z-10 w-full max-w-[480px] overflow-hidden rounded-t-[32px] sm:rounded-[32px] border-2 border-cyan-400/70 bg-gradient-to-b from-[#0a1835]/98 via-[#060e22]/98 to-[#030712]/98 p-5 sm:p-6 text-white shadow-[0_0_80px_rgba(0,229,255,0.5)] backdrop-blur-2xl">
        {/* Mobile Drag Indicator */}
        <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-cyan-400/40 sm:hidden" />

        {/* Top Header */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-white/10">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 rounded-full bg-cyan-400 animate-ping" />
              <h3 className="text-[17px] font-black text-white">حفظ الفيديو إلى استوديو الصور</h3>
            </div>
            <p className="mt-1 line-clamp-1 text-[12.5px] font-bold text-slate-300">
              {title || "فيديو عالي الجودة"}
            </p>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white transition active:scale-90 cursor-pointer"
            title="إغلاق"
          >
            <IconX size={18} />
          </button>
        </div>

        {/* Status Content */}
        {status === "downloading" ? (
          <div className="py-7 flex flex-col items-center justify-center text-center gap-3">
            <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-400/20 text-cyan-300 animate-pulse">
              <IconSpinner size={34} />
            </div>

            <div className="mt-2">
              <h4 className="text-[17px] font-black text-white">جارٍ جلب الفيديو بأعلى جودة…</h4>
              <p className="mt-1 text-[12.5px] text-cyan-300 font-semibold">
                يتم التجهيز للمشاركة المباشرة إلى ألبوم الصور
              </p>
            </div>

            {/* Glowing progress bar */}
            <div className="mt-3 w-full max-w-xs h-2 rounded-full bg-slate-800 overflow-hidden border border-cyan-400/30">
              <div
                className="h-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 transition-all duration-300 shadow-[0_0_12px_rgba(0,229,255,0.8)]"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="text-[11.5px] font-bold text-slate-400 tabular-nums">
              {progressPercent}%
            </span>
          </div>
        ) : status === "error" ? (
          <div className="py-6 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-red-500/20 text-red-400 mb-3">
              <IconAlert size={26} />
            </div>
            <h4 className="text-[16px] font-black text-white">تعذّر حفظ الفيديو</h4>
            <p className="mt-1 text-[13px] text-red-200">{errorMessage}</p>
            <button
              onClick={onClose}
              className="mt-4 rounded-xl border border-white/10 bg-white/10 px-6 py-2.5 text-[13px] font-black text-white hover:bg-white/20 transition cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        ) : (
          <div className="mt-4 flex flex-col gap-3">
            {/* Embedded Video Preview Player */}
            {videoBlobUrl && (
              <div className="overflow-hidden rounded-2xl border border-cyan-400/40 bg-black shadow-[0_0_25px_rgba(0,229,255,0.2)] relative aspect-video w-full flex items-center justify-center">
                <video
                  src={videoBlobUrl}
                  controls
                  playsInline
                  autoPlay
                  preload="auto"
                  className="h-full w-full object-contain"
                />
              </div>
            )}

            {/* The One True Big Button: Direct Share to Photos */}
            <button
              onClick={triggerShareNow}
              disabled={isSharing}
              className="exact-action-btn flex w-full items-center justify-center gap-2.5 rounded-2xl py-4 text-[16.5px] font-black text-white shadow-2xl transition-all hover:scale-[1.01] active:scale-[0.98] cursor-pointer anim-laser mt-1"
            >
              {isSharing ? (
                <IconSpinner size={22} className="text-white" />
              ) : (
                <IconShare size={22} className="stroke-[2.5]" />
              )}
              <span>حفظ في استوديو الصور (Save Video) 📲</span>
            </button>

            {/* Quick Helper Note */}
            <div className="rounded-2xl border border-cyan-400/30 bg-black/60 p-3.5 text-right">
              <p className="text-[12.5px] font-black text-cyan-300 mb-1 flex items-center gap-1.5">
                <IconCheck size={15} className="text-cyan-400" />
                <span>طريقة الحفظ المباشر:</span>
              </p>
              <p className="text-[12px] text-slate-200 leading-relaxed font-semibold">
                عند الضغط على الزر أعلاه، تفتح قائمة مشاركة الآيفون / الأندرويد، اختر منها{" "}
                <span className="text-cyan-300 font-black">«حفظ الفيديو» (Save Video)</span> ليذهب مباشرة إلى ألبوم الصور بهاتفك.
              </p>
            </div>

            {/* Fallback Buttons */}
            <div className="grid grid-cols-2 gap-2 mt-1">
              <button
                onClick={handleDirectDownload}
                className="flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/5 py-2.5 text-[12px] font-bold text-slate-300 hover:text-white transition cursor-pointer"
              >
                <IconDown size={15} />
                <span>تنزيل كملف MP4</span>
              </button>

              <button
                onClick={handleCopy}
                className="flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/5 py-2.5 text-[12px] font-bold text-slate-300 hover:text-white transition cursor-pointer"
              >
                {copied ? <IconCheckCircle size={14} className="text-emerald-400" /> : <IconCopy size={14} />}
                <span>{copied ? "تم النسخ!" : "نسخ الرابط"}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
