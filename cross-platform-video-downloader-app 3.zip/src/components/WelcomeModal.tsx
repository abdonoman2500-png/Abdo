"use client";

import { useEffect, useRef, useState } from "react";
import { BrandCube, SahhabCloudLogo } from "@/components/icons";

interface WelcomeModalProps {
  onEnter: () => void;
}

// Ultra-short intro (approx 2.4s) - fluid, energetic & gorgeous
const INTRO_SECONDS = 2.4;

export function WelcomeModal({ onEnter }: WelcomeModalProps) {
  const [closing, setClosing] = useState(false);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const start = Date.now();
    const totalMs = INTRO_SECONDS * 1000;

    const interval = setInterval(() => {
      const elapsed = Date.now() - start;
      const pct = Math.min(100, (elapsed / totalMs) * 100);
      setProgress(pct);

      if (elapsed >= totalMs) {
        clearInterval(interval);
        handleClose();
      }
    }, 35);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = 1.8;
      videoRef.current.play().catch(() => {});
    }
  }, []);

  function handleClose() {
    setClosing(true);
    setTimeout(() => {
      onEnter();
    }, 280);
  }

  return (
    <div
      onClick={handleClose}
      className={`fixed inset-0 z-[120] flex items-center justify-center bg-[#02050c] text-white overflow-hidden select-none cursor-pointer transition-all duration-300 ${
        closing ? "opacity-0 scale-105 pointer-events-none" : "opacity-100 scale-100"
      }`}
    >
      {/* ---------------- Video Background with Moving Haze ---------------- */}
      <div className="absolute inset-0">
        <video
          ref={videoRef}
          src="/videos/open-laptop.mp4"
          muted
          playsInline
          autoPlay
          className="h-full w-full object-cover filter brightness-70 contrast-125"
        />
        {/* Animated fluid blur gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#02050c] via-black/45 to-[#02050c]/80" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,229,255,0.45)_0%,rgba(168,85,247,0.25)_45%,transparent_75%)] animate-pulse" />
      </div>

      {/* Floating Glowing Aura Orbs */}
      <div className="pointer-events-none absolute -top-16 -left-16 h-72 w-72 rounded-full bg-cyan-400/35 blur-3xl animate-[pulse_3s_ease-in-out_infinite]" />
      <div className="pointer-events-none absolute -bottom-16 -right-16 h-80 w-80 rounded-full bg-purple-500/30 blur-3xl animate-[pulse_3s_ease-in-out_infinite_reverse]" />

      {/* ---------------- Center Floating Branding & App Icons ---------------- */}
      <div className="relative z-10 flex flex-col items-center justify-center p-4 pointer-events-none text-center max-w-md">
        {/* Glowing Central Cloud Logo with Abboud name */}
        <div className="anim-neon-pulse drop-shadow-[0_0_50px_rgba(0,229,255,1)] mb-3">
          <SahhabCloudLogo size={98} />
        </div>

        {/* Phrase requested by user */}
        <div className="inline-flex items-center gap-1.5 rounded-full border border-cyan-400/40 bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-purple-500/20 px-4 py-1 text-[12.5px] font-black text-cyan-200 backdrop-blur-md shadow-[0_0_25px_rgba(0,229,255,0.4)] mb-2">
          <span>✨ مرحبًا بك في عبود لتحميل الفيديو</span>
        </div>

        <h1 className="text-[44px] md:text-[54px] font-black tracking-tight gradient-abboud-title leading-tight drop-shadow-[0_0_40px_rgba(0,229,255,0.95)]">
          عبود
        </h1>
        <p className="mt-1 text-[15px] font-bold text-slate-200 drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)]">
          حمّل أي فيديو من أي تطبيق إلى جهازك مباشرة
        </p>

        {/* 7 Floating 3D App Icons with Staggered Bounce */}
        <div className="mt-5 flex items-center justify-center gap-2.5 drop-shadow-[0_0_25px_rgba(0,229,255,0.6)]">
          <BrandCube brand="tiktok" size={44} className="animate-bounce [animation-delay:0ms]" />
          <BrandCube brand="youtube" size={44} className="animate-bounce [animation-delay:80ms]" />
          <BrandCube brand="instagram" size={44} className="animate-bounce [animation-delay:160ms]" />
          <BrandCube brand="snapchat" size={44} className="animate-bounce [animation-delay:240ms]" />
          <BrandCube brand="x" size={44} className="animate-bounce [animation-delay:320ms]" />
          <BrandCube brand="facebook" size={44} className="animate-bounce [animation-delay:400ms]" />
          <BrandCube brand="telegram" size={44} className="animate-bounce [animation-delay:480ms]" />
        </div>

        <p className="mt-4 text-[11px] font-bold text-cyan-400/90 tracking-wide">
          (دخول فوري تلقائي...)
        </p>
      </div>

      {/* Top Quick Skip Button */}
      <div className="absolute top-4 right-4 z-50 pointer-events-auto">
        <button
          onClick={handleClose}
          className="flex items-center gap-1.5 rounded-full border border-cyan-400/50 bg-black/60 px-4 py-1.5 text-[12px] font-black text-cyan-300 backdrop-blur-md transition hover:bg-cyan-500/20 active:scale-95 cursor-pointer shadow-[0_0_20px_rgba(0,229,255,0.4)]"
        >
          <span>تخطي</span>
          <span>⤹</span>
        </button>
      </div>

      {/* Bottom Fast Progress Line */}
      <div className="absolute bottom-0 inset-x-0 h-1.5 bg-slate-900/80 z-50">
        <div
          className="h-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 shadow-[0_0_15px_rgba(0,229,255,1)] transition-all duration-75"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}
