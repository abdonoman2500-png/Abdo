import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { size?: number };

function base(size?: number) {
  return {
    width: size ?? 20,
    height: size ?? 20,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
}

export const IconBolt = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H12L13 2z" />
  </svg>
);

export const IconDown = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M12 3v12" />
    <path d="m7 10 5 5 5-5" />
    <path d="M4 21h16" />
  </svg>
);

export const IconPaste = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <rect x="8" y="2" width="8" height="4" rx="1" />
    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
  </svg>
);

export const IconSparkles = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z" />
  </svg>
);

export const IconShield = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
  </svg>
);

export const IconFlame = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z" />
  </svg>
);

export const IconPlay = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="currentColor" stroke="none">
    <path d="M8 5.5v13a1 1 0 0 0 1.53.85l10.2-6.5a1 1 0 0 0 0-1.7L9.53 4.65A1 1 0 0 0 8 5.5z" />
  </svg>
);

export const IconShare = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <circle cx="18" cy="5" r="3" />
    <circle cx="6" cy="12" r="3" />
    <circle cx="18" cy="19" r="3" />
    <path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4" />
  </svg>
);

export const IconCheck = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="m4 12.5 5 5L20 6.5" />
  </svg>
);

export const IconX = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M18 6 6 18M6 6l12 12" />
  </svg>
);

export const IconAlert = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M12 3 2.5 20h19L12 3z" />
    <path d="M12 10v4M12 17.5v.5" />
  </svg>
);

export const IconFilm = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <rect x="3" y="4" width="18" height="16" rx="2" />
    <path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4" />
  </svg>
);

export const IconLink = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
  </svg>
);

export const IconRefresh = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M21 12a9 9 0 1 1-2.64-6.36" />
    <path d="M21 3v6h-6" />
  </svg>
);

export const IconSpinner = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} className={`animate-spin ${p.className ?? ""}`}>
    <path d="M12 3a9 9 0 1 0 9 9" />
  </svg>
);

export const IconPlus = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);

export const IconEye = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

export const IconHelp = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <circle cx="12" cy="12" r="10" />
    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
    <path d="M12 17h.01" />
  </svg>
);

export const IconDevice = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <rect x="5" y="2" width="14" height="20" rx="2" />
    <line x1="12" y1="18" x2="12.01" y2="18" strokeWidth={3} />
  </svg>
);

export const IconGlobe = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <circle cx="12" cy="12" r="10" />
    <line x1="2" y1="12" x2="22" y2="12" />
    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
  </svg>
);

export const IconCheckCircle = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <circle cx="12" cy="12" r="10" />
    <path d="m9 12 2 2 4-4" />
  </svg>
);

export const IconCopy = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
  </svg>
);

/* ------------------------------------------------------------------ */
/* Glowing Neon Cloud Logo (Exact match to the provided reference)   */
/* ------------------------------------------------------------------ */
export function SahhabCloudLogo({ size = 80, className = "" }: { size?: number; className?: string }) {
  return (
    <div
      style={{ width: size, height: size }}
      className={`relative inline-flex items-center justify-center shrink-0 ${className}`}
    >
      {/* Background radial glow */}
      <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-cyan-500/40 via-purple-500/40 to-pink-500/40 blur-xl animate-pulse" />

      <svg width={size} height={size} viewBox="0 0 100 100" fill="none" className="relative drop-shadow-[0_0_20px_rgba(0,210,255,0.7)]">
        <defs>
          <linearGradient id="cloudNeonGrad" x1="10" y1="20" x2="90" y2="80" gradientUnits="userSpaceOnUse">
            <stop stopColor="#00e5ff" />
            <stop offset="0.5" stopColor="#3877ff" />
            <stop offset="0.8" stopColor="#a855f7" />
            <stop offset="1" stopColor="#ec4899" />
          </linearGradient>

          <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Cloud Outline */}
        <path
          d="M32 70 H68 C80 70 88 60 86 48 C85 38 77 31 68 31 C66 20 54 14 42 18 C33 21 26 29 26 39 C16 41 10 50 12 60 C14 67 22 70 32 70 Z"
          stroke="url(#cloudNeonGrad)"
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter="url(#neonGlow)"
          fill="rgba(10, 20, 45, 0.55)"
        />

        {/* Download arrow pointing down inside the cloud */}
        <path
          d="M50 36 V54"
          stroke="url(#cloudNeonGrad)"
          strokeWidth="6"
          strokeLinecap="round"
          filter="url(#neonGlow)"
        />
        <path
          d="M40 46 L50 56 L60 46"
          stroke="url(#cloudNeonGrad)"
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter="url(#neonGlow)"
        />
      </svg>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* 3D App Cubes (Matching the floating icons in the image)            */
/* ------------------------------------------------------------------ */

export function BrandCube({
  brand,
  size = 52,
  className = "",
}: {
  brand: "tiktok" | "youtube" | "instagram" | "snapchat" | "x" | "facebook" | "telegram";
  size?: number;
  className?: string;
}) {
  const configs = {
    tiktok: {
      bg: "from-[#111] via-[#090b10] to-[#000]",
      border: "border-cyan-400/40 shadow-[0_0_20px_rgba(0,229,255,0.4)]",
      content: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
          <path d="M19.589 6.686a4.793 4.793 0 0 1-3.77-4.245V2h-3.445v13.672a2.896 2.896 0 0 1-5.201 1.743 2.9 2.9 0 0 1 3.109-4.64v-3.52a6.353 6.353 0 0 0-4.492 1.957 6.427 6.427 0 0 0 4.14 10.788c3.551 0 6.444-2.893 6.444-6.444V9.014c1.238.884 2.738 1.408 4.364 1.455V6.98a4.832 4.832 0 0 1-1.149-.294z" />
        </svg>
      ),
    },
    youtube: {
      bg: "from-[#dc2626] via-[#b91c1c] to-[#7f1d1d]",
      border: "border-red-400/50 shadow-[0_0_22px_rgba(239,68,68,0.5)]",
      content: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
          <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
        </svg>
      ),
    },
    instagram: {
      bg: "from-[#f59e0b] via-[#ec4899] to-[#8b5cf6]",
      border: "border-pink-400/50 shadow-[0_0_22px_rgba(236,72,153,0.5)]",
      content: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
          <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" strokeWidth="3" />
        </svg>
      ),
    },
    snapchat: {
      bg: "from-[#facc15] via-[#eab308] to-[#ca8a04]",
      border: "border-yellow-300/60 shadow-[0_0_22px_rgba(250,204,21,0.5)]",
      content: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000">
          <path d="M12.001 2.2c-3.5 0-5.4 2.6-5.4 5.3 0 .9.3 2.1.8 2.8-.4.2-1.3.4-1.8.4-.5 0-.8-.1-.9-.3-.2-.3 0-.7.2-1.1.2-.4.1-.7-.1-.9-.3-.2-.7-.1-.9.3-.5 1-.4 2.2.3 2.8.5.5 1.4.5 2.1.2.3.8.9 1.4 1.7 1.8-.8.3-1.8.8-2.6 1.4-.8.6-.6 1.1-.3 1.3.4.2 1.4.1 2.6-.4.4-.2.8-.2 1.2.1.6.4 1.6 1 3 1 1.4 0 2.4-.6 3-1 .4-.3.8-.3 1.2-.1 1.2.5 2.2.6 2.6.4.3-.2.5-.7-.3-1.3-.8-.6-1.8-1.1-2.6-1.4.8-.4 1.4-1 1.7-1.8.7.3 1.6.3 2.1-.2.7-.6.8-1.8.3-2.8-.2-.4-.6-.5-.9-.3-.2.2-.3.5-.1.9.2.4.4.8.2 1.1-.1.2-.4.3-.9.3-.5 0-1.4-.2-1.8-.4.5-.7.8-1.9.8-2.8 0-2.7-1.9-5.3-5.4-5.3z" />
        </svg>
      ),
    },
    x: {
      bg: "from-[#222] via-[#111] to-[#050505]",
      border: "border-white/30 shadow-[0_0_20px_rgba(255,255,255,0.3)]",
      content: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
        </svg>
      ),
    },
    facebook: {
      bg: "from-[#3b82f6] via-[#2563eb] to-[#1d4ed8]",
      border: "border-blue-400/50 shadow-[0_0_22px_rgba(59,130,246,0.5)]",
      content: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
        </svg>
      ),
    },
    telegram: {
      bg: "from-[#38bdf8] via-[#0284c7] to-[#0369a1]",
      border: "border-cyan-300/50 shadow-[0_0_22px_rgba(56,189,248,0.5)]",
      content: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
          <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.121l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.536-.195 1.006.128.832.942z" />
        </svg>
      ),
    },
  };

  const cfg = configs[brand];

  return (
    <div
      style={{ width: size, height: size }}
      className={`relative flex items-center justify-center rounded-2xl bg-gradient-to-br ${cfg.bg} border ${cfg.border} backdrop-blur-md transform transition-all duration-300 hover:scale-110 active:scale-95 ${className}`}
    >
      <div className="absolute inset-0 rounded-2xl bg-white/10 pointer-events-none" />
      {cfg.content}
    </div>
  );
}

export function LogoMark({ size = 36 }: { size?: number }) {
  return <SahhabCloudLogo size={size} />;
}
