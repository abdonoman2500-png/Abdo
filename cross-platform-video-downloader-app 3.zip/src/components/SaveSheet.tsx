"use client";

import { useEffect, useRef, useState } from "react";
import {
  IconAlert,
  IconCheck,
  IconCheckCircle,
  IconCopy,
  IconDown,
  IconEye,
  IconFilm,
  IconShare,
  IconShield,
  IconSparkles,
  IconSpinner,
  IconX,
} from "@/components/icons";
import { formatBytes } from "@/lib/platforms";

export interface SaveTarget {
  url: string;
  quality: string;
  title: string;
  filename?: string | null;
  size?: number | null;
}

type Phase = "preparing" | "ready" | "shared" | "error";

interface ShareNav {
  canShare?: (data: { files: File[] }) => boolean;
  share?: (data: { files?: File[]; title?: string; text?: string; url?: string }) => Promise<void>;
}

function isIOSDevice(): boolean {
  if (typeof navigator === "undefined") return false;
  return (
    /iphone|ipad|ipod/i.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)
  );
}

export function SaveSheet({ target, onClose }: { target: SaveTarget | null; onClose: () => void }) {
  const [phase, setPhase] = useState<Phase>("preparing");
  const [fileBlob, setFileBlob] = useState<Blob | null>(null);
  const [videoBlobUrl, setVideoBlobUrl] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [ios] = useState<boolean>(() => isIOSDevice());
  const [copied, setCopied] = useState(false);
  const [isSharing, setIsSharing] = useState(false);

  // Fetch the actual video blob as soon as modal target is set
  useEffect(() => {
    if (!target) {
      if (videoBlobUrl) URL.revokeObjectURL(videoBlobUrl);
      setVideoBlobUrl(null);
      setFileBlob(null);
      setPhase("preparing");
      setNote("");
      return;
    }

    setPhase("preparing");
    setFileBlob(null);
    setNote("");

    const ctrl = new AbortController();

    (async () => {
      try {
        const query = new URLSearchParams({
          url: target.url,
          quality: target.quality || "best",
          title: "video",
        });

        const res = await fetch(`/api/download?${query.toString()}`, { signal: ctrl.signal });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const blob = await res.blob();
        setFileBlob(blob);

        const vUrl = URL.createObjectURL(blob);
        setVideoBlobUrl(vUrl);
        setPhase("ready");
      } catch (e) {
        if (!ctrl.signal.aborted) {
          setPhase("error");
          setNote("تعذّر تجهيز ملف الفيديو من المصدر. يرجى التأكد من اتصال الإنترنت وإعادة المحاولة.");
        }
      }
    })();

    return () => {
      ctrl.abort();
    };
  }, [target]);

  if (!target) return null;

  const sizeLabel = formatBytes(fileBlob?.size ?? target.size ?? undefined);

  /* ---------------- Direct Native OS Share Sheet Trigger ---------------- */
  async function triggerNativeShare() {
    if (!fileBlob || !target) return;
    setIsSharing(true);
    setNote("");

    const nav = navigator as unknown as ShareNav;

    // Use a safe clean ASCII filename so Apple's sharing daemon doesn't choke on emojis/unicode
    const safeName = "video.mp4";
    const shareableFile = new File([fileBlob], safeName, { type: "video/mp4" });

    if (nav.share) {
      try {
        // Attempt native file share (triggers "Save Video" on iOS Photos & Gallery on Android)
        await nav.share({
          files: [shareableFile],
          title: target.title || "فيديو",
        });
        setPhase("shared");
        setIsSharing(false);
        return;
      } catch (err: unknown) {
        const error = err as { name?: string; message?: string };
        if (error?.name === "AbortError") {
          // User closed the share sheet
          setNote("أغلقت نافذة المشاركة — اضغط الزر مرة أخرى واختر «حفظ الفيديو» (Save Video).");
          setIsSharing(false);
          return;
        }

        // If files array was refused, fallback to sharing the direct link
        try {
          const downloadUrl =
            window.location.origin +
            `/api/download?url=${encodeURIComponent(target.url)}&title=${encodeURIComponent(
              target.title || "video"
            )}`;
          await nav.share({
            title: target.title || "فيديو",
            url: downloadUrl,
          });
          setPhase("shared");
          setIsSharing(false);
          return;
        } catch {
          // Fall through to manual save
        }
      }
    }

    // Fallback: Direct Download anchor if browser lacks share API
    downloadAsFile();
    setIsSharing(false);
  }

  function downloadAsFile() {
    if (!fileBlob) return;
    const obj = URL.createObjectURL(fileBlob);
    const a = document.createElement("a");
    a.href = obj;
    a.download = `${target?.title || "video"}.mp4`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(obj), 8000);
    setNote("تم بدء تنزيل الملف إلى جهازك مباشرة.");
  }

  function copyVideoLink() {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(target?.url || "").then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      });
    }
  }

  return (
    <div className="fixed inset-0 z-[110] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md select-none">
      {/* Background click to dismiss */}
      <button aria-label="إغلاق" onClick={onClose} className="absolute inset-0 h-full w-full cursor-default" />

      {/* Cyber Holographic Modal */}
      <div className="anim-rise relative z-10 w-full max-w-[500px] overflow-hidden rounded-t-[32px] sm:rounded-[32px] border-2 border-cyan-400/60 bg-gradient-to-b from-[#0a1835]/98 via-[#060e22]/98 to-[#030712]/98 p-5 sm:p-6 text-white shadow-[0_0_70px_rgba(0,229,255,0.45)] backdrop-blur-2xl max-h-[92dvh] overflow-y-auto no-scrollbar">
        {/* Top Drag Indicator for mobile */}
        <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-cyan-400/40 sm:hidden" />

        {/* Header */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-white/10">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 rounded-full bg-cyan-400 animate-ping" />
              <h3 className="text-[17px] font-black text-white">المشاركة إلى الجهاز وحفظ الفيديو</h3>
            </div>
            <p className="mt-1 line-clamp-1 text-[13px] font-bold text-slate-300">{target.title}</p>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-400 transition hover:bg-white/10 hover:text-white active:scale-90 cursor-pointer"
            title="إغلاق"
          >
            <IconX size={18} />
          </button>
        </div>

        {/* Badges Info */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="rounded-full px-3 py-1 text-[11px] font-black border border-cyan-400/40 bg-cyan-500/15 text-cyan-300">
            صيغة MP4 أصلية
          </span>
          {sizeLabel ? (
            <span className="rounded-full bg-white/5 border border-white/10 px-3 py-1 text-[11px] font-bold text-slate-300">
              {sizeLabel}
            </span>
          ) : null}
          <span className="rounded-full bg-emerald-500/15 border border-emerald-400/30 px-3 py-1 text-[11px] font-black text-emerald-300 flex items-center gap-1">
            <IconShield size={12} /> حفظ بالهاتف بدون جوجل
          </span>
        </div>

        {/* Inline Video Player Preview */}
        {videoBlobUrl && (
          <div className="mt-4 overflow-hidden rounded-2xl border border-cyan-400/40 bg-black shadow-[0_0_25px_rgba(0,229,255,0.2)] relative aspect-video w-full flex items-center justify-center">
            <video
              src={videoBlobUrl}
              controls
              playsInline
              preload="metadata"
              className="h-full w-full object-contain"
            />
          </div>
        )}

        {/* Dynamic States */}
        {phase === "preparing" ? (
          <div className="mt-5 flex flex-col items-center justify-center gap-3 rounded-2xl border border-cyan-400/30 bg-[#091838]/60 p-8 text-center">
            <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-400/20 text-cyan-300 animate-pulse">
              <IconSpinner size={32} />
            </div>
            <p className="text-[15px] font-black text-white">جارٍ تجهيز ملف الفيديو للمشاركة المباشرة...</p>
            <p className="text-[12px] text-cyan-200">لحظات قليلة وسيظهر زر فتح المشاركة إلى جهازك فوراً</p>
          </div>
        ) : phase === "error" ? (
          <div className="mt-5 rounded-2xl border border-red-500/40 bg-[#1f0b0f]/80 p-4 text-center">
            <p className="text-[13px] font-semibold text-red-200 leading-relaxed">{note}</p>
            <button
              onClick={onClose}
              className="mt-3 rounded-xl border border-white/10 bg-white/10 px-5 py-2 text-[12px] font-black text-white hover:bg-white/20 cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        ) : (
          <div className="mt-5 flex flex-col gap-3">
            {/* The One True Button: Triggers Native Share Sheet Directly */}
            <button
              onClick={triggerNativeShare}
              disabled={isSharing}
              className="exact-action-btn flex w-full items-center justify-center gap-2.5 rounded-2xl py-4 text-[16px] font-black text-white shadow-2xl transition-all hover:scale-[1.01] active:scale-[0.98] cursor-pointer anim-laser"
            >
              {isSharing ? (
                <IconSpinner size={22} className="text-white" />
              ) : (
                <IconShare size={22} className="stroke-[2.5]" />
              )}
              <span>اضغط هنا للمشاركة إلى الجهاز وحفظ الفيديو 📲</span>
            </button>

            {/* Step Explanation for iPhone / Android */}
            <div className="rounded-2xl border border-cyan-400/30 bg-black/60 p-4 text-right">
              <p className="text-[13px] font-black text-cyan-300 mb-1.5 flex items-center gap-1.5">
                <IconCheck size={16} className="text-cyan-400" />
                <span>كيفية الحفظ في استوديو الصور مباشرة (بدون جوجل):</span>
              </p>
              <ol className="text-[12px] text-slate-300 space-y-1.5 list-decimal list-inside font-semibold leading-relaxed">
                <li>
                  اضغط الزر الملون بالأعلى <strong>«اضغط هنا للمشاركة إلى الجهاز»</strong>.
                </li>
                <li>
                  ستفتح قائمة مشاركة النظام الخاصة بهاتفك فوراً.
                </li>
                <li>
                  اختر <strong>«حفظ الفيديو» (Save Video)</strong> على الآيفون أو <strong>«المعرض / Photos»</strong> على الأندرويد، وسيتم الحفظ في استوديو الصور فوراً!
                </li>
              </ol>
            </div>

            {/* Direct Fallback Option */}
            <button
              onClick={downloadAsFile}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 py-2.5 text-[12px] font-bold text-slate-300 hover:text-white transition cursor-pointer"
            >
              <IconDown size={15} />
              <span>أو تنزيل الملف في مجلد التنزيلات بالجهاز</span>
            </button>

            {/* Quick Copy Link */}
            <button
              onClick={copyVideoLink}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 py-2 text-[11.5px] font-bold text-slate-400 hover:text-white transition cursor-pointer"
            >
              {copied ? <IconCheckCircle size={14} className="text-emerald-400" /> : <IconCopy size={14} />}
              <span>{copied ? "تم نسخ الرابط الأصلي!" : "نسخ رابط الفيديو"}</span>
            </button>

            {note ? (
              <div className="mt-1 flex items-start gap-2 rounded-xl border border-cyan-400/30 bg-cyan-950/40 p-2.5 text-[12px] font-semibold text-cyan-200">
                <IconAlert size={16} className="shrink-0 text-cyan-400 mt-0.5" />
                <span>{note}</span>
              </div>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );
}
